// Will Must be first 
// Make sure you add them alphabetically 
var monsterPages = {
    Cthulhu: "Cthulhu",    
    Dragon: "Dragon",
    Golem: "Golem",
 };
