Use : live-server

https://github.com/tapio/live-server


# Hellsoffspring To do list  
* ~~gzip site~~
* Facebook and Twitter share 
* Make dropdown look better on mobile

## James Needs to do 
* ~~Make basic pages work /site.js:147 & index.html:46~~
* Make back button work 
* Get content to pull from html files (pages/html/monsterName)
* ~~sort list in alphabetical order~~
	* Do it by hand 
* ~~progressive web app~~ 
	* worked on my phone 
* ~~Set up domain~~
	* Also adding ssl
* ~~Set up FTP~~
	* Information in Google Doc

## Will Needs to do 
* Come up with design 
* ~~Make logos~~
* ~~Make mascot~~
* Make list of first monsters (min: 25)
* Make Pages for monsters 
* ~~Set up loacl~~
* ~~Set up Git~~

## Pages That Need Made 
* About 
* Comment / Submit Ideas 

## Bugs 
* Page did not load once when picking a monster 
* Mobile cant pick from dropdown when on page (/#about)
