var name = "Dragon";
var img = "Dragon.jpg";
var meter = "67";
var description = "giant dragon with octopus head and stands on 2 legs can use argiant dragon with octopugiant dragon with octopus head and stands on 2 legs can use argiant dragon with octopu <br /> giant dragon with octopus head and stands on 2 legs can use argiant dragon with octopugiant dragon with octopus head and stands on 2 legs can use argiant dragon with octopu<h2>sdfsdfsdfsdf</h2> giant dragon with octopus head and stands on 2 legs can use argiant dragon with octopugiant dragon with octopus head and stands on 2 legs can use argiant dragon with octopugiant dragon with octopus head and stands on 2 legs can use argiant dragon with octopugiant dragon with octopus head and stands on 2 legs can use argiant dragon with octopu";
var lives = "Lives in caves";
var kill = "Can only be killed with a sword forged from dragon's blood";
var eats = "Eats large animals ";