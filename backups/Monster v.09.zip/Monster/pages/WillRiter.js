var name = "Will Riter";
var img = "Will_Riter.jpg";
var meter = "1";
var description = "William James Riter was born in the year of 2004, when the earth was flat and the sky was red.  Well you can sometimes find him doing homework and eating on the leftover from the day before.  He enjoys riding his bike at the skate park. <br /> Will is what is called a <b>human</b>, but he is not really a tall human.";
var lives = "The desert of nevada ";
var kill = "Getting up for school";
var eats = "Popcorn & Pool Water ";