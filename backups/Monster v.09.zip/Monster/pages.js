var monsterPages = {
    WillRiter: "Will Riter",
    Dragon: "Dragon",
    Golem: "Golem",
    Cthulhu: "Cthulhu",
 };