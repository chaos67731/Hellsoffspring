Use : live-server
https://github.com/tapio/live-server

