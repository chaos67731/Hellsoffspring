var name = "Golem";
var img = "Golem.png";
var meter = "40";
var description = "a golem is an animated anthropomorphic being that is magically created entirely from inanimate matter only attack on masters comand a golem is an animated anthropomorphic being that is magically created entirely from inanimate matter only attack on masters comand a golem is an animated anthropomorphic being that is magically created entirely from inanimate matter only attack on masters comand a golem is an animated anthropomorphic being that is magically created entirely from inanimate matter only attack on masters comand a golem is an animated anthropomorphic being that is magically created entirely from inanimate matter only attack on masters comand a golem is an animated anthropomorphic being that is magically created entirely from inanimate matter only attack on masters comand a golem is an animated anthropomorphic being that is magically created entirely from inanimate matter only attack on masters comand a golem is an animated anthropomorphic being that is magically created entirely from inanimate matter only attack on masters comand a golem is an animated anthropomorphic being that is magically created entirely from inanimate matter only attack on masters comand a golem is an animated anthropomorphic being that is magically created entirely from inanimate matter only attack on masters comand ";
var lives = "lives wherever the master tells it to ";
var kill = "you can kill it by killing its master";
var eats = "Eats nothing ";

