var monster = {
    Dragon: "Dragon",
    Golem: "Golem",
    Cthulhu: "Cthulhu",

 };